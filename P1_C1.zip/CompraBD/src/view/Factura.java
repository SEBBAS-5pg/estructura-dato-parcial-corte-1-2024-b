package view;

import java.util.Scanner;
import logic.Compra;

public class Factura {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try{
            System.out.print("Ingrese el nombre del cliente: ");
            String nombreCliente = scanner.nextLine();
            System.out.print("Ingrese el nombre del producto: ");
            String nombreProducto = scanner.nextLine();
            System.out.print("Ingrese el valor unitario del producto: ");
            double valorUnitario = scanner.nextDouble();
            if(valorUnitario<=0){
                System.out.println("Error en la entrada de datos");
                return;
            }
            System.out.println("Ingrese la cantidad a comprar: ");
            int cantidad = scanner.nextInt();
            if(cantidad<=0){
                System.out.println("error en la entrada de datos");
                return;
            }
            Compra compra = new Compra(nombreCliente,nombreProducto,valorUnitario,cantidad);
            compra.mostrarFactura();
        }catch (Exception e){
            System.out.println("Error en la entrada de datos");
        }finally {
            scanner.close();
        }
    }
}
