package logic;

import javax.swing.plaf.synth.SynthOptionPaneUI;
import java.util.Scanner;

public class Compra {
    private String nombreCliente = "";
    private String nombreProducto = "";
    private double valorUnitario = 0;
    private int cantidad = 0;

    public Compra(String nombreCliente, String nombreProducto, double valorUnitario, int cantidad) {
        this.nombreCliente = nombreCliente;
        this.nombreProducto = nombreProducto;
        this.valorUnitario = valorUnitario;
        this.cantidad = cantidad;
    }
    public double calcularValorBruto(){
        return valorUnitario*valorUnitario;
    }
    public double calcularDescuento(){
        double valorBruto = calcularValorBruto();
        if(cantidad>=10 && cantidad < 20){
            return 0.05*valorBruto;
        }else if(cantidad>=20){
            return 0.07*valorBruto;
        }
        return 0;
    }
    public double calcularValorNeto(){
        return calcularValorBruto()-calcularDescuento();
    }
    public void mostrarFactura(){
        System.out.println("\n--- FACTURA ---\n"+
                "CLiente: "+nombreCliente+"\n"+
                "Producto: "+nombreProducto+"\n"+
                "Valor unitario: "+valorUnitario+"\n"+
                "Cantidad: "+cantidad+"\n"+
                "Valor bruto"+calcularValorBruto()+"\n"+
                "Descuento: "+calcularDescuento()+"\n"+
                "Valor neto: "+calcularValorNeto());


    }
}
